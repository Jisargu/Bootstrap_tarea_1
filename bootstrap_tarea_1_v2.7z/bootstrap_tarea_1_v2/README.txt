A Pen created at CodePen.io. You can find this one at https://codepen.io/jisargu/pen/XqXxvK.

 Tarea 1 usando bootstrap para una página web